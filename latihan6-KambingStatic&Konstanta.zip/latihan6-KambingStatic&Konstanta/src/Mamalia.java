/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Firman Ardhiansyah IF 2 10117056 
 */
public class Mamalia {
    //variabel jumlahKambing dideklarasikan sebagai statik
        public static int jumlahKambing;
        
}

public class  {

//NAMA_KAMBING sebagai konstanta 
    public static final String NAMA_KAMBING = "MIDUN";
    
    public static void main(String[] args){
        Mamalia.jumlahKambing = 485000;
        System.out.println(NAMA_KAMBING + " memiliki kambing sebanyak " + Mamalia.jumlahKambing);
        
        
    }
}

    

